import React from "react";
import { View, Text, StyleSheet, ScrollView, ImageBackground, Image } from "react-native";
import { DrawerNavigatorItems } from "react-navigation-drawer";
import Ionicons from "react-native-vector-icons/Ionicons";

export default SideBar = props => (
	<ScrollView>
		<ImageBackground source={require("../assets/background.jpg")} style={{ width: undefined, padding: 16, paddingTop: 48 }}>
			<Image source={require("../assets/profile-pic.jpeg")} style={ styles.profile } />
			<Text style={ styles.name }>Izzat alharis</Text>
			
			<View style={{ flexDirection: "row"}}>
				<Ionicons name="md-people" size={16} color="rgba(255, 255, 255, 0.8)" />
				<Text style={ styles.followers }>200 Followers</Text>
			</View>
		</ImageBackground>

		<View style={ styles.container }>
			<DrawerNavigatorItems {...props} />
		</View>
	</ScrollView>
);

const styles = StyleSheet.create({
	container: {
		flex: 1
	},
	profile: {
		width: 80,
		height: 80,
		borderRadius: 40,
		borderWidth: 1,
		borderColor: "#fff",
		marginBottom: 10
	},
	name: {
		color: "#fff",
		fontSize: 20,
		fontWeight: "800",
		marginVertical: 8
	},
	followers: {
		color: "rgba(255, 255, 255, 0.8)",
		fontSize: 12,
		marginLeft: 7
	}
});