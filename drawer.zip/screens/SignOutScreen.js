import React from "react";
import { View, Text, StyleSheet, BackHandler, Button } from "react-native";

export default class SignOutScreen extends React.Component {

	closeApp = ()=>
	{
		BackHandler.exitApp();
	}
	render()
	{
		return (
			<View style={ styles.container }>

				<Text style={ styles.title }>					
					Anda yakin ingin menutup aplikasi ini?
				</Text>

				<Button color="#8300A0" onPress={ this.closeApp } title="Iya" />
				
			</View>
		);
	}
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		paddingHorizontal: 20,
		paddingVertical: 50
	},
	title: {
		fontSize: 16,
		paddingBottom: 10
	}
});