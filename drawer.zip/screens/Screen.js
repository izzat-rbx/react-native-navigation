import * as React from 'react';
import { FontAwesome5 } from "@expo/vector-icons";
import {  View, StyleSheet,  SafeAreaView, TouchableOpacity } from "react-native";

export default class Screen extends React.Component {
  render()
  {
    return (
      <View style={ styles.container }>
        <SafeAreaView style={{ flex: 1 }}>
          <TouchableOpacity style={{ alignItems: "flex-end", margin: 16 }} onPress={ this.props.navigation.openDrawer }>
            <FontAwesome5  name="bars" size={ 24 } color="#161924" style={{ marginTop: 10 }} />
          </TouchableOpacity>
          <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
            { this.props.content }
          </View>
        </SafeAreaView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff"
  },
  text: {
    color: "#161924",
    fontSize: 20,
    fontWeight: "500"
  }
});