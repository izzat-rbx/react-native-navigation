import * as React from "react";
import Screen from "./Screen";
import Profile from "./ProfileScreen";
import Message from "./MessageScreen";
import Activity from "./ActivityScreen";
import List from "./ListScreen";
import Report from "./ReportScreen";
import Statistic from "./StatisticScreen";
import SignOut from "./SignOutScreen";

export const ProfileScreen = ({ navigation }) => <Screen navigation={ navigation } content={ <Profile name="Profile" /> } />
export const MessageScreen = ({ navigation }) => <Screen navigation={ navigation } content={ <Message  name="Message" /> } />
export const ActivityScreen = ({ navigation }) => <Screen navigation={ navigation } content={ <Activity  name="Activity" /> } />
export const ListScreen = ({ navigation }) => <Screen navigation={ navigation } content={ <List name="List" /> } />
export const ReportScreen = ({ navigation }) => <Screen navigation={ navigation } content={ <Report name="Report" /> } />
export const StatisticScreen = ({ navigation }) => <Screen navigation={ navigation } content={ <Statistic name="Statistic" /> } />
export const SignOutScreen = ({ navigation }) => <Screen navigation={ navigation } content={ <SignOut name="SignOut" /> } />