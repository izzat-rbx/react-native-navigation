import React from "react";
import { View, Text, StyleSheet } from "react-native";

export default class ReportScreen extends React.Component {

	render()
	{
		return (
			<View style={ styles.container }>

				<Text style={ styles.title }>{ this.props.name } Screen</Text>
				<Text style={ styles.text }>					
					Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
					Sequi perferendis exercitationem quam dolorem quasi ex quisquam 
					sit eveniet aspernatur voluptas ratione perspiciatis fuga saepe 
					voluptates fugit, commodi non pariatur maxime.
				</Text>
				
			</View>
		);
	}
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		paddingHorizontal: 20
	},
	title: {
		fontSize: 20,
		paddingBottom: 10
	},
	text: {
		fontSize: 13
	}
});